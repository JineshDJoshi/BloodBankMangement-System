package com.app.pojos;

public enum ReqStatus {
 PENDING, ACCEPTED, REGECTED
}
