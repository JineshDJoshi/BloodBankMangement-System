package com.app.pojos;

public enum Gender {
	FEMALE, MALE,TRANSGENDER
}
