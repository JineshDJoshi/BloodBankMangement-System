package com.app.pojos;

public enum ComponentFacility {
YES, NO
}
