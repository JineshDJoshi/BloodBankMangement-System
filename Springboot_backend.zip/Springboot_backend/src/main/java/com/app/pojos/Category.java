package com.app.pojos;

public enum Category {
	GOVT, RED_CROSS, CHARITABLE, PRIVATE
}
