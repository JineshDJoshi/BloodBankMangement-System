package com.app.pojos;

public enum UserRole {
 DONOR, ADMIN, BANK
}
