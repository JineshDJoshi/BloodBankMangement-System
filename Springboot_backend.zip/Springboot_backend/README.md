# BloodBankManagementSystem

This project is developed to manage the blood stock in the "BLOOD BANK" and the blood details 
are maintained in the database. New blood details are entered in to the project to manage blood details. 
Blood donor details are entered and maintained in the database.
